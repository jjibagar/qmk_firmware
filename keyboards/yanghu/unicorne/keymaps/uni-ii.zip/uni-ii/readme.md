![keymap](https://imgur.com/48cFzA5.jpg)

# Default Unicorne Layout

This is the default layout for Unicorne. The "lower" layer consists of symbols
and navigation, while "raises' has numbers, some other symbols and function
keys.

Press `lower` and `raise` together activates `adjust` layer, with RGB controls,
as well as access to reset/bootloader.
