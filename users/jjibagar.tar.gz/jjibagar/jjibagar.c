
// esto me da problemas, si no lo quito no compila
// alfred lo tiene en jjibañez.c y en el keymap
//#include "jjibagar.h"
//#include "muse.h"
//#include "keymap_spanish_dvorak.h"
//#include "sendstring_spanish_dvorak.h"
//#include "combos.c"
